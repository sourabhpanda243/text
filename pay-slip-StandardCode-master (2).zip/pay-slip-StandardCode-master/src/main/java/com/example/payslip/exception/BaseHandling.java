package com.example.payslip.exception;


public class BaseHandling extends Throwable {
}
